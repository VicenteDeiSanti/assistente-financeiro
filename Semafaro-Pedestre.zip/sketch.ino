// Semáforo de Pedestres com Arduino

const int ledVerde = 10;
const int ledAmarelo = 11;
const int ledVermelho = 12;
const int botaoPedestreo = 2;

volatile boolean travessiaAcionada = false;

unsigned long ultimoTempoInterrupcao = 0;
const unsigned long debounceDelay = 200;

void setup() {

  pinMode(ledVerde, OUTPUT);
  pinMode(ledAmarelo, OUTPUT);
  pinMode(ledVermelho, OUTPUT);

  pinMode(botaoPedestreo, INPUT_PULLUP);

  attachInterrupt(
    digitalPinToInterrupt(botaoPedestreo),
    acionarTravessia,
    FALLING
  );

  Serial.begin(9600);

  apagarTodos();
  digitalWrite(ledVerde, HIGH);

  Serial.println("[VERDE] Sistema pronto - fluxo normal");
}

void loop() {

  if (travessiaAcionada) {

    travessiaAcionada = false;

    Serial.println("[CLICK] Botao pressionado");

    executarSemafo();

    apagarTodos();
    digitalWrite(ledVerde, HIGH);

    Serial.println("[VERDE] Voltou ao normal");
  }
}

void acionarTravessia() {

  unsigned long agora = millis();

  if (agora - ultimoTempoInterrupcao > debounceDelay) {

    travessiaAcionada = true;
    ultimoTempoInterrupcao = agora;
  }
}

void executarSemafo() {

  // AMARELO
  apagarTodos();
  digitalWrite(ledAmarelo, HIGH);
  Serial.println("[AMARELO] Atencao");
  delay(2000);

  // VERMELHO
  apagarTodos();
  digitalWrite(ledVermelho, HIGH);
  Serial.println("[VERMELHO] Pedestre pode passar");
  delay(5000);
}

void apagarTodos() {

  digitalWrite(ledVerde, LOW);
  digitalWrite(ledAmarelo, LOW);
  digitalWrite(ledVermelho, LOW);
}